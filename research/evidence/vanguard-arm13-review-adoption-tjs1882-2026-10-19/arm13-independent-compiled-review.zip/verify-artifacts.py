import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess

S = Path(__file__).resolve().parent
P = S / 'packet'
E = P / 'research/evidence/vanguard-arm13-build-tjs1882-2026-10-19'
K = S / 'package/meownero-vanguard-windows-aarch64'
results = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def git(commit, path):
    return subprocess.check_output(['git', 'show', commit + ':' + path])

def sums(root, count=None):
    rows = (root / 'SHA256SUMS').read_text().splitlines()
    for line in rows:
        h, name = line.split(maxsplit=1)
        name = name.lstrip('*')
        assert '..' not in Path(name).parts and not Path(name).is_absolute()
        assert sha(root / name) == h, name
    if count is not None:
        assert len(rows) == count
    return len(rows)

results['packet_internal_hashes'] = sums(P, 146)
bindings = json.loads((P / 'SOURCE-BINDINGS.json').read_text())
for row in bindings['files']:
    data = (P / row['packet_path']).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256']
    assert git(row['commit'], row['repository_path']) == data
results['packet_git_bindings'] = len(bindings['files'])
assert results['packet_git_bindings'] == 141

release = json.loads((K / 'release.json').read_text())
assert release['target'] == 'windows-aarch64' and release['architecture'] == 'aarch64'
assert release['status'] == 'BUILT_UNTESTED'
assert release['native_journey'] == release['native_version_execution'] == 'UNTESTED'
assert sha(K / 'release.json') == '676994c2752e419d50cb5b3a74a98304f2f6819e60d2e9b0fa2ef6461958c5a0'
actual = {str(p.relative_to(K)) for p in K.rglob('*') if p.is_file()}
assert actual == set(release['files']) | {'release.json'}
for path, h in release['files'].items():
    assert sha(K / path) == h, path
results['archive_internal_hashes'] = len(release['files'])
assert results['archive_internal_hashes'] == 294
for path in ['release.json', 'license-coverage.json', 'TESTER.md']:
    assert (K / path).read_bytes() == (E / 'archive-metadata' / path).read_bytes()
    assert (K / path).read_bytes() == (S / 'delivery/archive-metadata' / path).read_bytes()

pin = json.loads(git('6fb3c3ec4a8e6a13dcbec7b638525556d4f84568', 'vanguard/source-lock.json'))
build = json.loads((K / 'BUILD.json').read_text())
assert build == json.loads((E / 'attempt02-native-build/build-receipt.json').read_text())
assert build['source_lock'] == pin
assert release['upstream_commit'] == pin['upstream']['commit'] == 'e151643c5269c83bf24a83b2548e2493876026b2'
assert release['cargo_lock_sha256'] == pin['rust']['cargo_lock_sha256']
assert release['submodules'] == pin['upstream']['submodules']
assert all(x['removed'] for x in build['containers'])
assert all(x['reaped'] for x in build['commands'])
for name, path in [('tester.py', 'vanguard/portable-tester.py'), ('portable_windows.py', 'vanguard/portable_windows.py'), ('TESTER.md', 'docs/vanguard-portable-tester.md')]:
    assert (K / name).read_bytes() == git('6fb3c3ec4a8e6a13dcbec7b638525556d4f84568', path)
results['exact_source_build_and_launcher_bindings'] = 'PASS'

def inspect_pe(path):
    data = path.read_bytes()
    def u16(at): return struct.unpack_from('<H', data, at)[0]
    def u32(at): return struct.unpack_from('<I', data, at)[0]
    assert data[:2] == b'MZ'
    off = u32(60)
    assert data[off:off + 4] == b'PE\0\0' and u16(off + 4) == 0xaa64
    count, optional_size = u16(off + 6), u16(off + 20)
    optional = off + 24
    assert u16(optional) == 0x20b and optional_size >= 240
    assert u32(optional + 108) >= 14
    dirs = [struct.unpack_from('<II', data, optional + 112 + i * 8) for i in range(14)]
    assert dirs[4] == (0, 0), 'Authenticode directory must be absent'
    assert dirs[13] == (0, 0), 'delay imports must be absent'
    sections = []
    for i in range(count):
        at = optional + optional_size + 40 * i
        virtual_size, rva, raw_size, ptr = struct.unpack_from('<IIII', data, at + 8)
        assert ptr + raw_size <= len(data)
        sections.append((rva, raw_size, ptr))
    def offset(rva, size=1):
        for base, n, ptr in sections:
            if base <= rva and rva + size <= base + n:
                return ptr + rva - base
        raise AssertionError('RVA outside raw sections')
    def string(rva):
        at = offset(rva)
        end = data.index(b'\0', at, min(at + 256, len(data)))
        return data[at:end].decode('ascii')
    imports = []
    irva, isize = dirs[1]
    assert irva and isize
    for i in range(isize // 20):
        at = offset(irva + i * 20, 20)
        row = struct.unpack_from('<IIIII', data, at)
        if row == (0, 0, 0, 0, 0): break
        imports.append(string(row[3]))
    else: raise AssertionError('unterminated import table')
    assert imports and len(imports) == len(set(imports))
    expected = release['pe_audit'][path.name]
    assert sorted(imports) == expected['imports']
    assert sha(path) == expected['sha256']
    return {'sha256': sha(path), 'machine': '0xaa64', 'optional_magic': '0x20b',
            'imports': sorted(imports), 'authenticode': False, 'delay_imports': False}

results['pe_programs'] = {p.name: inspect_pe(p) for p in sorted((K / 'bin').iterdir())}
assert len(results['pe_programs']) == 3
all_imports = {x.lower() for p in results['pe_programs'].values() for x in p['imports']}
assert all_imports == set(release['required_dynamic_libraries'])
allowed = {'advapi32.dll','bcrypt.dll','bcryptprimitives.dll','crypt32.dll','iphlpapi.dll','kernel32.dll','mswsock.dll','ntdll.dll','shell32.dll','user32.dll','ws2_32.dll'}
assert all(n in allowed or n.startswith(('api-ms-win-', 'ext-ms-win-')) for n in all_imports)
assert 'msvcrt.dll' not in all_imports and any(x.startswith('api-ms-win-crt-') for x in all_imports)

coverage = json.loads((K / 'license-coverage.json').read_text())
assert coverage['result'] == 'PASS_LINKED_DEPENDENCY_COVERAGE'
texts = set()
for component in coverage['components']:
    assert component['texts']
    for p, h in component['texts'].items():
        assert sha(K / p) == h
        texts.add(p)
assert coverage['rust_coverage']['covered_count'] == coverage['rust_coverage']['required_count'] == 79
boost = next(c for c in coverage['components'] if c['component'] == 'boost')
assert len(boost['libraries']) == 10 and all(x.endswith('.lib') for x in boost['libraries'])
results['license_coverage'] = {'components': len(coverage['components']), 'unique_notice_files': len(texts), 'rust_crates':79, 'boost_libraries':10}

final = json.loads((E / 'final-preservation.json').read_text())
for row in final['frozen_bindings']:
    assert digest(git('3071ff1276aae8cb96ef13619b3fcbb11a6adb8d', row['carrier'])) == row['sha256']
    if row['carrier'] not in ('vanguard/run-portable-ci.py', 'vanguard/run-portable-linux-ci.py'):
        assert sha(Path(row['carrier'])) == row['sha256']
assert len(final['frozen_bindings']) == 36
for path in ('vanguard/run-portable-ci.py', 'vanguard/run-portable-linux-ci.py'):
    assert Path(path).read_bytes() == git('b1af96dabd4d34198e06d05e4f777bd9f55e781a', path)
for path, h in final['six_original_file_hashes'].items():
    assert sha(Path(path)) == h
results['frozen_bindings'] = 36
results['preexisting_files'] = 6
results['reviewed_local_linux_helpers'] = 2
results['result'] = 'PASS_EXACT_ARTIFACT_STATIC_AND_SOURCE_BINDINGS'
results['native_windows_execution'] = 'UNTESTED'
(S / 'artifact-checks.json').write_text(json.dumps(results, indent=2) + '\n')
print(results['result'], results['packet_git_bindings'], results['archive_internal_hashes'])
