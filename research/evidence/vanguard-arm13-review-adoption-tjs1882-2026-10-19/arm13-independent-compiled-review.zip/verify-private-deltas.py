import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import shutil
import struct
import tempfile

S = Path(__file__).resolve().parent
P = S / 'packet'
E = P / 'research/evidence/vanguard-arm13-build-tjs1882-2026-10-19'
K = S / 'private-kit'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

old = load('review_original_inventory', P / 'base-source/vanguard/portable_licenses.py')
new = load('review_candidate_inventory', K / 'vanguard/portable_licenses.py')
rows = []
with tempfile.TemporaryDirectory(dir=S, prefix='inventory-real-links-') as temp:
    source = Path(temp) / 'monero-fcmp'
    build = source / 'build/portable'
    depends = source / 'contrib/depends/aarch64-w64-mingw32'
    for target in ['daemon', 'simplewallet', 'wallet_rpc_server']:
        folder = 'wallet' if target == 'wallet_rpc_server' else target
        root = build / 'src' / folder / 'CMakeFiles' / (target + '.dir')
        root.mkdir(parents=True)
        for name in ['link.txt', 'linkLibs.rsp', 'objects1.rsp']:
            shutil.copyfile(E / 'link-and-object-evidence' / target / name, root / name)
    original = old.link_inventory(source, build, depends, (Path('/out/monero-fcmp'),), True)
    changed = new.link_inventory(source, build, depends, (Path('/out/monero-fcmp'),), True)
    boost = {name for name in changed[1] if name.startswith('libboost_')}
    assert original[0] == changed[0]
    assert original[0] == json.loads((E / 'archive-metadata/license-coverage.json').read_text())['link_commands']
    assert len(boost) == 10 and all(x.endswith('.lib') for x in boost)
    assert changed[1] - original[1] == boost and not original[1] - changed[1]
    assert changed[3] - original[3] == {(x, 'pinned_depends') for x in boost}
    rows.append({'case': 'exact-retained-linker-responses-original-gap-and-correction', 'result':'PASS', 'boost_archives_added':10})
    archived_headers = {}
    for name in sorted(boost):
        header = (E / 'link-and-object-evidence' / (name + '.headers.txt')).read_text()
        machines = re.findall(r'Machine: (.+)', header)
        assert machines and all(v == 'IMAGE_FILE_MACHINE_ARM64 (0xAA64)' for v in machines)
        assert 'Format: COFF-import-file' not in header
        archived_headers[name] = len(machines)
    for target in ['daemon', 'simplewallet', 'wallet_rpc_server']:
        folder = 'wallet' if target == 'wallet_rpc_server' else target
        root = build / 'src' / folder / 'CMakeFiles' / (target + '.dir')
        (root / 'link.txt').write_text('c++')
    def links(token):
        for file in build.rglob('link.txt'):
            file.write_text(shlex.join(['c++', str(token)]))
    for label, token in [('absolute', depends/'lib/libboost_filesystem.lib'),
                         ('relative','../../../contrib/depends/aarch64-w64-mingw32/lib/libboost_filesystem.lib'),
                         ('container',Path('/out/monero-fcmp/contrib/depends/aarch64-w64-mingw32/lib/libboost_filesystem.lib'))]:
        if label == 'relative':
            import os
            token = os.path.relpath(depends/'lib/libboost_filesystem.lib', build/'src/daemon')
        links(token)
        assert new.link_inventory(source,build,depends,(Path('/out/monero-fcmp'),),True)[1] == {'libboost_filesystem.lib'}
        assert new.link_inventory(source,build,depends,(Path('/out/monero-fcmp'),),False)[1] == set()
        rows.append({'case':label+'-windows-only-lib','result':'PASS'})
    for label, token in [('wrong-target',source/'contrib/depends/wrong/lib/libboost_filesystem.lib'),
                         ('wrong-directory',depends/'else/libboost_filesystem.lib'),
                         ('project-imposter',build/'src/libboost_filesystem.lib'),
                         ('system-imposter',Path(temp)/'system/libboost_filesystem.lib'),
                         ('unmapped-contrib',source/'contrib/private/unknown.lib')]:
        links(token)
        try: new.link_inventory(source,build,depends,(Path('/out/monero-fcmp'),),True)
        except AssertionError: pass
        else: raise AssertionError('accepted unsafe .lib origin '+label)
        rows.append({'case':label,'result':'PASS_REFUSAL'})

# Bind new controller behavior while proving the other function bodies are unchanged.
def functions(path):
    return {n.name:ast.dump(n) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
before = functions(P/'base-source/vanguard/run-portable-ci.py')
after = functions(K/'vanguard/run-portable-ci.py')
assert set(after)-set(before) == {'windows_arm64_qualification'}
assert set(before)-set(after) == set()
assert {n for n in before if before[n]!=after[n]} == {'windows_check','main','public_check'}

# Independently decode the retained, actual compiled translation unit's COFF symbols.
data = (E/'link-and-object-evidence/slow-hash.c.obj').read_bytes()
machine, count, timestamp, sym_at, sym_count, optional, flags = struct.unpack_from('<HHIIIHH',data)
assert machine == 0xaa64 and optional == 0
string_at = sym_at + sym_count*18
undefined=[]
i=0
while i < sym_count:
    at=sym_at+18*i
    name=data[at:at+8]
    if name[:4] == bytes(4):
        offset=int.from_bytes(name[4:],'little');end=data.index(b'\0',string_at+offset)
        name=data[string_at+offset:end]
    else: name=name.rstrip(b'\0')
    value,section,kind,storage,aux=struct.unpack_from('<IhHBB',data,at+8)
    if section==0 and storage==2: undefined.append(name.decode())
    i += 1+aux
assert sorted(undefined) == json.loads((E/'compiled-slow-hash-witness.json').read_text())['undefined_symbols']
assert {'IsProcessorFeaturePresent','__imp_VirtualAlloc','__imp_VirtualFree'} <= set(undefined)
assert not {'mmap','munmap','getauxval'} & set(undefined)
result={'result':'PASS_PRIVATE_DELTA_SOURCE_AND_RETAINED_LINK_EVIDENCE','inventory_cases':rows,
        'retained_boost_coff_header_members':archived_headers,'controller_changed_functions':['public_check','windows_check','main'],
        'controller_added_function':'windows_arm64_qualification','retained_compiled_object_machine':'0xaa64',
        'retained_compiled_object_undefined_symbols':sorted(undefined),
        'limits':'Actual .lib archives were removed by the writer; their retained exact header outputs were reviewed. No new cross compilation or native Windows execution.'}
(S/'private-delta-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['result'],len(rows))
