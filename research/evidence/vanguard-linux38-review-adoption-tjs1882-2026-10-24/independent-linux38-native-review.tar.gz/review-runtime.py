import hashlib, importlib.util, json, os, platform, signal, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
os.umask(0o077)
BASE=Path(__file__).resolve().parent
KIT=BASE/'kit'
sys.path.insert(0,str(KIT/'vanguard'))
import linux38_docker as provider

def write(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def load(name):
 spec=importlib.util.spec_from_file_location('review_'+name.replace('-','_').replace('.py',''),KIT/'vanguard'/name)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def worker():
 def cancel(number,frame): raise RuntimeError('independent reviewer runtime cancelled')
 signal.signal(signal.SIGTERM,cancel)
 binding=BASE/'provenance-private.json'
 with provider.shared_lock():
  admitted=provider.admit(binding,provider.sha(binding),'linux-x86_64')
  qualified=provider.resources(BASE)
  write(BASE/'qualification.json',{'schema':'meownero-independent-linux38-qualification/1','result':'PASS_LIVE_QUALIFICATION_ONLY','observed_utc':datetime.now(timezone.utc).isoformat(),'admission':admitted,'resources':qualified})
  runtime=load('run-portable-check.py')
  sys.argv=['run-portable-check.py','--archive',str(BASE/'meownero-vanguard-linux38-x86_64.tar.gz'),'--sha256','fc4bde3b0a665bebcd22140fbc67fad2f15b5c841252a18dff0d5c5d79d56743','--target','linux-x86_64','--runtime-image','sha256:92b52376b9ebd2bd2393a878e73fc3da072901c1a24e20fdd9f5522591d9338f','--out',str(BASE/'runtime')]
  runtime.main()

if len(sys.argv)>1 and sys.argv[1]=='worker': worker()
else:
 with provider.shared_lock():
  info=json.loads(provider.query('info','--format','{{json .}}'))
  observed={'observed_utc':datetime.now(timezone.utc).isoformat(),'system':platform.system(),'architecture':platform.machine(),'python':platform.python_version(),'glibc':subprocess.check_output(['getconf','GNU_LIBC_VERSION'],text=True).strip(),'kernel':platform.release(),'machine_id_sha256':provider.sha(Path('/etc/machine-id')),'boot_id_sha256':provider.sha(Path('/proc/sys/kernel/random/boot_id')),'docker_id_sha256':hashlib.sha256(info['ID'].encode()).hexdigest(),'docker_version':info['ServerVersion'],'available_memory_bytes':int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024}
  write(BASE/'observations.json',observed)
  binding={'schema':'meownero-linux38-native-docker/1','issue':'TJS-1882','target':'linux-x86_64','machine_id_sha256':observed['machine_id_sha256'],'boot_id_sha256':observed['boot_id_sha256'],'kernel':platform.release(),'docker_id':info['ID'],'docker_name':info['Name'],'docker_root':info['DockerRootDir'],'docker_version':info['ServerVersion'],'qualification_evidence_sha256':provider.sha(BASE/'observations.json')}
  write(BASE/'provenance-private.json',binding)
  print('fresh available memory bytes',observed['available_memory_bytes'],flush=True)
  assert observed['available_memory_bytes']>=6*1024**3,'fresh memory below six GiB; no workload admitted'
 supervisor=load('run-portable-ci.py')
 private=BASE/'supervision';private.mkdir(mode=0o700)
 public=private/'public';public.mkdir(mode=0o700)
 supervisor.mac_check([sys.executable,'-B',__file__,'worker'],private,public,timeout=1500,cleanup_seconds=180,supervision_schema='meownero-independent-linux38-runtime-supervision/1',failure_label='independent native Linux38 review')
 print('PASS_INDEPENDENT_LINUX38_RUNTIME_AND_SUPERVISION',flush=True)
